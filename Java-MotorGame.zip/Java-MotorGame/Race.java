


import javax.swing.JFrame;
 
public class Race extends JFrame
{
	private Thread thread;
	private boolean running=false;
	public Race () {
		JFrame gframe=new JFrame("KindOf-HangOn");
		Game game=new Game("HangOn");
		
		gframe.add(game);
		gframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gframe.setSize(500, 720);
		gframe.setVisible(true);
		gframe.setResizable(false);
	}
	
}

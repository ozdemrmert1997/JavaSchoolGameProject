



import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
public class Launcher extends JFrame implements ActionListener{

	public static int flag = 0 ;
	// static String Driver;
public static void main(String[] args) {
		
		
	
	
		JFrame frame = new JFrame("KindOf-Hang-On");
		JButton play,exit,rules,SignUp,ScoreBoard,newuser,adminRun;
		play = new JButton("Start");
		exit = new JButton("Exit");
		rules= new JButton("Rules");
		SignUp = new JButton("SignUp");
		ScoreBoard = new JButton("Scoreboard");
		adminRun = new JButton("Admin Run");
		
		BufferedImage img = null ;
		img = Assets.mbc ;
		
		ImageIcon icon = new ImageIcon(Launcher.class.getResource("maxresdefault.jpg"));
		Image scaleImage = icon.getImage().getScaledInstance(400, 400, Image.SCALE_DEFAULT);
		ImageIcon imageIcon = new ImageIcon(scaleImage);
		frame.setContentPane(new JLabel(imageIcon));
		
		//frame.setContentPane(new JLabel());
		frame.add(play);
		frame.add(rules);
		frame.add(exit);
		frame.add(SignUp);
		frame.add(adminRun);

		frame.add(ScoreBoard);
		ScoreBoard.setBounds(300, 300, 20, 20);
		frame.setLayout(new FlowLayout());
		frame.setSize(400,400);  
		frame.setVisible(true);  
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		play.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent b)
			{
				if(flag == 1)
				{
					Race game = new Race();
					frame.setVisible(false);
				}	
				else
				{
					JOptionPane.showMessageDialog(null, "Warning",":(",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		SignUp.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent b)
			{
				Login player = new Login();
			}
		});
		
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				System.exit(0);
			}	
		});
		
		
		
		rules.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				JOptionPane.showMessageDialog(null, "Race to death","Rules",JOptionPane.PLAIN_MESSAGE);
				
			}
		});
		adminRun.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
			
				Race game = new Race();
				
			}
		});
		ScoreBoard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				flag = 1;
				Race game = new Race();
				
			}
		});
}
	@Override
	public void actionPerformed(ActionEvent e)
	{
		// TODO Auto-generated method stub
		
	}
}

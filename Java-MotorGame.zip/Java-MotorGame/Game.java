


import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;

import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;


public class Game extends JPanel implements KeyListener
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int space;
	private int width=80;
	private int height=100;
	private double speed;
	public static int WIDTH=500;
	public static int HEIGHT=700;
	private int move=20;
	public int health = 3 ;
	private ArrayList <Rectangle> bikes;
	private ArrayList <Rectangle> line;
	private Rectangle car;
	private Random rand;
	BufferedImage ground;
	BufferedImage road;
	BufferedImage player;
	BufferedImage bot,bot2;
	BufferedImage road2;
	Boolean linef=true;
	private Thread the;
	
	
	
	
	
	
	public Game(String Title){
		try
		{
			ground=ImageIO.read(new File("C:Desktop\\dy\\kum.jpg"));
			road=ImageIO.read(new File("C:\\Desktop\\dy\\road.jpg"));
			player=ImageIO.read(new File("C:\\Desktop\\JavaPhoto\\motorr1111.png"));
			bot=ImageIO.read(new File("C:\\Desktop\\JavaPhoto\\havali2.png"));
			bot2=ImageIO.read(new File("C:Desktop\\JavaPhoto\\motorr1111.png"));
		
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Thread thread = new Thread(new Runnable() {

			@Override
			public void run() {
				Boolean threadCheck = true ;
				while(threadCheck) {
					try {
						Thread.sleep(20);
					} 
					catch (InterruptedException e)
					{
						e.printStackTrace();
					}
					Engine();
				}
			}
		});

		
		rand=new Random();
		bikes = new ArrayList<Rectangle>(); 
		line=new ArrayList<Rectangle>(); 
		car=new Rectangle(WIDTH/2-10,HEIGHT-100,width-50,height-20);
		space=300;
		speed=4;
		addKeyListener(this);
		setFocusable(true);
		addocars(true);
		addocars(true);
	
		
		addlines(true);
		addlines(true);
		addlines(true);
		addlines(true);
		addlines(true);
		addlines(true);
		addlines(true);
		addlines(true);
		
		
		thread.start();
	}
	public void addlines(Boolean first){
		int x=WIDTH/2-2;
		int y=700;
		int width=4;
		int height=100;
		if(first){
			line.add(new Rectangle(x,y-(line.size()*space),width,height+100));
			line.add(new Rectangle(x,y-(line.size()*space)*2,width,height+100));
			line.add(new Rectangle(x,y-(line.size()*space)/2,width,height+100));
			line.add(new Rectangle(x-120,y-(line.size()*space),width+4,HEIGHT+1000));
			line.add(new Rectangle(x+120,y-(line.size()*space),width+4,HEIGHT+1000));
		}
		else{
			line.add(new Rectangle(x,line.get(line.size()-1).y-space ,width,height+100));
			line.add(new Rectangle(x,line.get(line.size()-1).y-space*2 ,width,height+100));
			line.add(new Rectangle(x,line.get(line.size()-1).y-space/2 ,width,height+100));
			line.add(new Rectangle(x-120,line.get(line.size()-1).y-space ,width+6,HEIGHT+1000));
			line.add(new Rectangle(x+120,line.get(line.size()-1).y-space ,width+6,HEIGHT+1000));
		}
	}
	public void addocars(boolean first){
		int positionx=rand.nextInt()%2;
		int x=0;
		int y=0;
		int Width=width;
		int Height=height;
		if(positionx==0){
			x=WIDTH/2-90;
		}
		else{
			x=WIDTH/2+10;
		}
		if(first){
			bikes.add(new Rectangle(x,y-100-(bikes.size()*space),Width,Height));
		}
		else{
			bikes.add(new Rectangle(x, bikes.get(bikes.size()-1).y-1000,Width,Height));
		}
		
		
	}

	public void paintComponent(Graphics g){
		super.paintComponents(g);
		g.drawImage(ground, 0, 0, null);
		for(Rectangle rect:bikes){
			
				g.drawImage(road,  WIDTH /2- 125, 0, null);

			
		}
		g.setColor(Color.yellow);
		for(Rectangle rect:line)
		{
			g.fillRect(rect.x, rect.y , rect.width , rect.height);
		}

		for(Rectangle rect:bikes)
		{
			g.drawImage(bot, rect.x-1 , rect.y-1, null);
			
		}
		
		g.drawImage(player, car.x , car.y, null);
		

	}
	
	public void Engine() {
		Rectangle rect;
		
		for(int i=0;i<bikes.size();i++){
			rect=bikes.get(i);
			rect.y += speed - 1 ;
			
		}
		for(Rectangle r:bikes){ 
			if(r.intersects(car))
			{

					car.y  = 1000000 ;
					System.out.print(health);
					
					
					
			}	
		}
		for(int i=0;i<bikes.size();i++)
		{
			rect=bikes.get(i);
			if(rect.y+rect.height>HEIGHT){
				bikes.remove(rect);
				addocars(false);
			}	
		}
		for(int i=0;i<line.size();i++)
		{
			rect=line.get(i);
			rect.y+=speed;
			health = health + 100 ;
		}
		for(int i=0;i<line.size();i++)
		{
			rect=line.get(i);
			if(rect.y>HEIGHT)
			{
				line.remove(rect);
				
				addlines(false);
			}	
		}
		
		repaint();
		
	}
	public void SpeedUp(){
		if(car.y-move<0){

		}
		else
		{
			speed  = speed + 0.10 ;
		}
	}
	
	
	public void SpeedDown(){
		if(car.y-move<0){
			System.out.println("\b");
		}
		else{
			//car.y+=move;
			speed = speed - 0.10 ;
		}
	}
	
	public void moveleft(){
		if(car.x-move<WIDTH/2-100){
			System.out.println("\b");
		}
		else
		{
			car.x=car.x - move + 15;
		}	
	}
	public void moveright(){
		if(car.x+move>WIDTH/2+80)
		{
			System.out.println("\b");
		
		}
		else
		{
			car.x = move + car.x - 10 ;
		}
	}
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		int key=e.getKeyCode();
		switch(key){
			
			case KeyEvent.VK_UP:
				SpeedUp();
				break;
			case KeyEvent.VK_DOWN:
				SpeedDown();
				break;
			
			case KeyEvent.VK_LEFT:
				moveleft();
				break;
			case KeyEvent.VK_RIGHT:
				moveright();
				break;
			default:
				break;
		}
	}
	// zorunlu ekliyor :p
	@Override
	public void keyReleased(KeyEvent e) {
		
	}
	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
	

}

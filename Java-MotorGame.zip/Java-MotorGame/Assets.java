import java.awt.image.BufferedImage;

public class Assets {

	public static BufferedImage mbc,enemy,background,player;
	public static void init() {
		
		mbc = ImageLoader.loadImage("/Res/maxresdefault.png");
		enemy = ImageLoader.loadImage("/Res/havali2.png");
		
	}
	
}
